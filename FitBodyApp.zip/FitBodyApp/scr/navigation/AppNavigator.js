import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/HomeScreen';
import ExerciseScreen from '../screens/ExerciseScreen';
import SummaryScreen from '../screens/SummaryScreen';

const Stack = createNativeStackNavigator();

const AppNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerStyle: {
          backgroundColor: '#4CAF50',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen 
        name="Home" 
        component={HomeScreen} 
        options={{ title: 'FitBody' }} 
      />
      <Stack.Screen 
        name="Exercise" 
        component={ExerciseScreen} 
        options={({ route }) => ({ title: route.params.type })} 
      />
      <Stack.Screen 
        name="Summary" 
        component={SummaryScreen} 
        options={{ title: 'ผลการออกกำลังกาย' }} 
      />
    </Stack.Navigator>
  );
};

export default AppNavigator;