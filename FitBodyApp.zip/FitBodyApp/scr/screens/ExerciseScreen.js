import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  Alert,
  SafeAreaView
} from 'react-native';
import { exerciseData } from '../data/exerciseData';

const ExerciseScreen = ({ route, navigation }) => {
  const { typeId } = route.params;
  const exercises = exerciseData[typeId] || [];
  
  const startWorkout = () => {
    if (exercises.length === 0) {
      Alert.alert('ไม่พบท่าออกกำลังกาย', 'ไม่มีท่าออกกำลังกายในประเภทนี้');
      return;
    }
    
    // คำนวณเวลาทั้งหมดในการออกกำลังกาย (วินาที)
    const totalDuration = exercises.reduce((sum, ex) => sum + ex.duration, 0);
    
    // ไปยังหน้า Summary พร้อมส่งข้อมูล
    navigation.navigate('Summary', {
      workoutType: route.params.type,
      exerciseCount: exercises.length,
      totalDuration: totalDuration,
    });
  };

  const renderExerciseItem = ({ item }) => (
    <View style={styles.exerciseItem}>
      <View style={styles.exerciseHeader}>
        <Text style={styles.exerciseIcon}>{item.icon}</Text>
        <View>
          <Text style={styles.exerciseName}>{item.name}</Text>
          <Text style={styles.exerciseDuration}>{item.duration} วินาที</Text>
        </View>
      </View>
      <Text style={styles.exerciseDescription}>{item.description}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.header}>ท่าออกกำลังกาย {route.params.type}</Text>
        
        <FlatList
          data={exercises}
          keyExtractor={(item) => item.id}
          renderItem={renderExerciseItem}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.list}
        />
        
        <TouchableOpacity
          style={styles.startButton}
          onPress={startWorkout}
        >
          <Text style={styles.startButtonText}>เริ่มออกกำลังกาย</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  list: {
    paddingBottom: 20,
  },
  exerciseItem: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  exerciseHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  exerciseIcon: {
    fontSize: 40,
    marginRight: 15,
  },
  exerciseName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  exerciseDuration: {
    fontSize: 14,
    color: '#666',
    marginTop: 3,
  },
  exerciseDescription: {
    fontSize: 14,
    color: '#555',
    lineHeight: 20,
  },
  startButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  startButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ExerciseScreen;