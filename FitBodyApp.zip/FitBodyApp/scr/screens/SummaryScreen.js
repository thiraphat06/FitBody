import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  SafeAreaView,
  Image
} from 'react-native';

const SummaryScreen = ({ route, navigation }) => {
  const { workoutType, exerciseCount, totalDuration } = route.params;
  
  // แปลงวินาทีเป็นนาที:วินาที
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };
  
  // คำนวณแคลอรี่โดยประมาณ (แค่ตัวอย่างเท่านั้น)
  const estimatedCalories = Math.round(totalDuration * 0.15);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.confetti}>
          <Text style={styles.emoji}>🎉</Text>
          <Text style={styles.emoji}>💪</Text>
          <Text style={styles.emoji}>🏆</Text>
        </View>
        
        <Text style={styles.congratsText}>เยี่ยม! คุณออกกำลังกายเสร็จแล้ว</Text>
        
        <View style={styles.summaryCard}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>ประเภทการออกกำลังกาย</Text>
            <Text style={styles.summaryValue}>{workoutType}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>จำนวนท่า</Text>
            <Text style={styles.summaryValue}>{exerciseCount} ท่า</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>เวลาทั้งหมด</Text>
            <Text style={styles.summaryValue}>{formatTime(totalDuration)}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>แคลอรี่โดยประมาณ</Text>
            <Text style={styles.summaryValue}>{estimatedCalories} กิโลแคลอรี่</Text>
          </View>
        </View>
        
        <View style={styles.motivationContainer}>
          <Text style={styles.motivationText}>
            "การออกกำลังกายที่ดีที่สุดคือการที่คุณทำอย่างสม่ำเสมอ ไม่ว่าจะเป็นเพียง 5 นาทีต่อวัน"
          </Text>
        </View>
        
        <TouchableOpacity
          style={styles.homeButton}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.homeButtonText}>กลับไปหน้าแรก</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  content: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confetti: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  emoji: {
    fontSize: 40,
    marginHorizontal: 10,
  },
  congratsText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4CAF50',
    textAlign: 'center',
    marginBottom: 30,
  },
  summaryCard: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    width: '100%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    marginBottom: 30,
  },
  summaryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  summaryLabel: {
    fontSize: 16,
    color: '#666',
  },
  summaryValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  motivationContainer: {
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  motivationText: {
    fontSize: 16,
    fontStyle: 'italic',
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
  },
  homeButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 30,
  },
  homeButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default SummaryScreen;