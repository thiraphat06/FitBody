import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Image, 
  SafeAreaView,
  StatusBar
} from 'react-native';

const HomeScreen = ({ navigation }) => {
  const exerciseTypes = [
    { id: 'cardio', name: 'คาร์ดิโอ', icon: '🏃', color: '#FF5722' },
    { id: 'strength', name: 'เวทเทรนนิ่ง', icon: '💪', color: '#2196F3' },
    { id: 'stretch', name: 'ยืดกล้ามเนื้อ', icon: '🧘', color: '#9C27B0' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      <View style={styles.header}>
        <Text style={styles.logo}>FitBody</Text>
        <Text style={styles.tagline}>เริ่มต้นฟิตใน 5 นาที</Text>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.sectionTitle}>เลือกประเภทการออกกำลังกาย</Text>
        
        {exerciseTypes.map(type => (
          <TouchableOpacity
            key={type.id}
            style={[styles.card, { backgroundColor: type.color }]}
            onPress={() => navigation.navigate('Exercise', { type: type.name, typeId: type.id })}
          >
            <Text style={styles.cardIcon}>{type.icon}</Text>
            <Text style={styles.cardText}>{type.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
      
      <View style={styles.footer}>
        <Text style={styles.footerText}>FitBody © 2025</Text>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#4CAF50',
  },
  logo: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 10,
  },
  tagline: {
    fontSize: 16,
    color: 'white',
    marginTop: 5,
    marginBottom: 10,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  cardIcon: {
    fontSize: 30,
    marginRight: 15,
  },
  cardText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  footer: {
    padding: 10,
    alignItems: 'center',
    backgroundColor: '#E0E0E0',
  },
  footerText: {
    color: '#757575',
  },
});

export default HomeScreen;