import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AppNavigator from './scr/navigation/AppNavigator';
import { StatusBar } from 'expo-status-bar';

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <AppNavigator />
    </NavigationContainer>
  );
}